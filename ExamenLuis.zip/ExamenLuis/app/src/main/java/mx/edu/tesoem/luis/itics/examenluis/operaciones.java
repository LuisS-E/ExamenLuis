package mx.edu.tesoem.luis.itics.examenluis;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class operaciones  extends AppCompatActivity {


    public void suma(View v){
        Inter cargar = new Inter(this,operaciones.class);
        startActivity(cargar);
    }


    public void resta (View v){
        Inter cargar = new Inter(this,operaciones.class);
        startActivity(cargar);
    }
    EditText num1,num2;
    TextView resultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_suma);

        num1 = (EditText) findViewById(R.id.txtnum1);
        num2 = (EditText) findViewById(R.id.txtnum2);
        resultado = (TextView) findViewById(R.id.labelresultado);
    }

    public void operaciones (View v){
        int a,b,r;
        a = Integer.parseInt(num1.getText().toString());
        b = Integer.parseInt(num2.getText().toString());
        r = a+b;
        r = a-b;

        resultado.setText(String.valueOf(r));
    }

}



